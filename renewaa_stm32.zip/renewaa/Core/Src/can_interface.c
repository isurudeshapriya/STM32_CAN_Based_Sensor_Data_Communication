/*
 * can_interface.c
 *
 *  Created on: Aug 12, 2025
 *      Author: ASUS
 */

#include "can_interface.h"
#include <string.h>

static CAN_HandleTypeDef *g_hcan = NULL;
static can_req_cb_t g_req_cb = NULL;

void CAN_IF_Init(CAN_HandleTypeDef *hcan) {
  g_hcan = hcan;

  CAN_FilterTypeDef filt;
  filt.FilterBank = 0;
  filt.FilterMode = CAN_FILTERMODE_IDMASK;
  filt.FilterScale = CAN_FILTERSCALE_32BIT;
  filt.FilterIdHigh = 0x0000;
  filt.FilterIdLow = 0x0000;
  filt.FilterMaskIdHigh = 0x0000;
  filt.FilterMaskIdLow = 0x0000;
  filt.FilterFIFOAssignment = CAN_FILTER_FIFO0;
  filt.FilterActivation = ENABLE;
  filt.SlaveStartFilterBank = 14;
  HAL_CAN_ConfigFilter(g_hcan, &filt);

  HAL_CAN_Start(g_hcan);
  HAL_CAN_ActivateNotification(g_hcan, CAN_IT_RX_FIFO0_MSG_PENDING);
}

bool CAN_IF_Send(CAN_HandleTypeDef *hcan, const CANMessage *msg) {
  CAN_TxHeaderTypeDef txh;
  txh.StdId = msg->id & 0x7FF;
  txh.IDE = CAN_ID_STD;
  txh.RTR = CAN_RTR_DATA;
  txh.DLC = msg->len;
  uint32_t mb;
  if (HAL_CAN_AddTxMessage(hcan, &txh, (uint8_t*)msg->data, &mb) != HAL_OK) return false;
  return true;
}

void CAN_IF_RegisterRequestCallback(can_req_cb_t cb) {
  g_req_cb = cb;
}

void HAL_CAN_RxFifo0MsgPendingCallback(CAN_HandleTypeDef *hcan) {
  CAN_RxHeaderTypeDef rxh;
  uint8_t data[8];
  if (HAL_CAN_GetRxMessage(hcan, CAN_RX_FIFO0, &rxh, data) != HAL_OK) return;

  CANMessage msg;
  memset(&msg,0,sizeof(msg));
  msg.id = rxh.StdId;
  msg.len = rxh.DLC;
  for (uint8_t i=0; i<msg.len; i++) msg.data[i] = data[i];

  if (g_req_cb) g_req_cb(&msg);
}

