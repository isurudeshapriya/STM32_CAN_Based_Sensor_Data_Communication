/*
 * adc.c
 *
 *  Created on: Aug 12, 2025
 *      Author: ASUS
 */


#include "adc.h"

// ADC handle declaration
ADC_HandleTypeDef hadc1;

void ADC_Init(void)
{
    ADC_ChannelConfTypeDef sConfig = {0};
    GPIO_InitTypeDef GPIO_InitStruct = {0};

    // 1. Enable GPIOA clock
    __HAL_RCC_GPIOA_CLK_ENABLE();

    // 2. Configure PA1 as analog input
    GPIO_InitStruct.Pin = GPIO_PIN_1;
    GPIO_InitStruct.Mode = GPIO_MODE_ANALOG;
    HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

    // 3. Enable ADC1 clock
    __HAL_RCC_ADC1_CLK_ENABLE();

    // 4. Configure ADC
    hadc1.Instance = ADC1;
    hadc1.Init.ScanConvMode = ADC_SCAN_DISABLE;             // single channel
    hadc1.Init.ContinuousConvMode = DISABLE;                 // single conversion mode
    hadc1.Init.DiscontinuousConvMode = DISABLE;
    hadc1.Init.ExternalTrigConv = ADC_SOFTWARE_START;        // software trigger
    hadc1.Init.DataAlign = ADC_DATAALIGN_RIGHT;
    hadc1.Init.NbrOfConversion = 1;
    if (HAL_ADC_Init(&hadc1) != HAL_OK)
    {
        // Initialization Error
        // You can add error handler here
    }

    // 5. Configure ADC channel 1 (PA1)
    sConfig.Channel = ADC_CHANNEL_1;
    sConfig.Rank = ADC_REGULAR_RANK_1;
    sConfig.SamplingTime = ADC_SAMPLETIME_55CYCLES_5;        // Sampling time, adjust if needed
    if (HAL_ADC_ConfigChannel(&hadc1, &sConfig) != HAL_OK)
    {
        // Channel Configuration Error
        // You can add error handler here
    }
}

uint16_t ADC_Read(void)
{
    uint16_t adcValue = 0;

    // Start ADC conversion
    HAL_ADC_Start(&hadc1);

    // Poll for conversion completion
    if (HAL_ADC_PollForConversion(&hadc1, 10) == HAL_OK)
    {
        // Get ADC value
        adcValue = HAL_ADC_GetValue(&hadc1);
    }

    // Stop ADC (optional here, since single conversion)
    HAL_ADC_Stop(&hadc1);

    return adcValue;
}
