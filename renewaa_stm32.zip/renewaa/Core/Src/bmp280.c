/*
 * bmp280.c
 *
 *  Created on: Aug 12, 2025
 *      Author: ASUS
 */
#include "bmp280.h"
#include <math.h>
#include <string.h>

#define BMP280_ADDR (0x76 << 1)

static struct {
  uint16_t dig_T1;
  int16_t dig_T2, dig_T3;
  uint16_t dig_P1;
  int16_t dig_P2, dig_P3, dig_P4, dig_P5, dig_P6, dig_P7, dig_P8, dig_P9;
  int32_t t_fine;
} calib;

static bool read_calib(I2C_HandleTypeDef *hi2c) {
  uint8_t buf[24];
  if (HAL_I2C_Mem_Read(hi2c, BMP280_ADDR, 0x88, 1, buf, 24, 100) != HAL_OK) return false;
  calib.dig_T1 = buf[0] | (buf[1]<<8);
  calib.dig_T2 = buf[2] | (buf[3]<<8);
  calib.dig_T3 = buf[4] | (buf[5]<<8);
  calib.dig_P1 = buf[6] | (buf[7]<<8);
  calib.dig_P2 = buf[8] | (buf[9]<<8);
  calib.dig_P3 = buf[10] | (buf[11]<<8);
  calib.dig_P4 = buf[12] | (buf[13]<<8);
  calib.dig_P5 = buf[14] | (buf[15]<<8);
  calib.dig_P6 = buf[16] | (buf[17]<<8);
  calib.dig_P7 = buf[18] | (buf[19]<<8);
  calib.dig_P8 = buf[20] | (buf[21]<<8);
  calib.dig_P9 = buf[22] | (buf[23]<<8);
  return true;
}

bool BMP280_Init(I2C_HandleTypeDef *hi2c) {
  uint8_t id;
  if (HAL_I2C_Mem_Read(hi2c, BMP280_ADDR, 0xD0, 1, &id, 1, 100) != HAL_OK) return false;
  if (id != 0x58) return false;
  if (!read_calib(hi2c)) return false;
  uint8_t cfg[2] = {0xF4, 0x27}; // ctrl_meas: temp+press oversampling x1, normal mode
  if (HAL_I2C_Master_Transmit(hi2c, BMP280_ADDR, cfg, 2, 100) != HAL_OK) return false;
  uint8_t cfg2[2] = {0xF5, 0xA0}; // config: standby 1000ms, filter x0
  HAL_I2C_Master_Transmit(hi2c, BMP280_ADDR, cfg2, 2, 100);
  return true;
}

bool BMP280_ReadPressure(I2C_HandleTypeDef *hi2c, float *pressure_hpa) {
  uint8_t buf[6];
  if (HAL_I2C_Mem_Read(hi2c, BMP280_ADDR, 0xF7, 1, buf, 6, 100) != HAL_OK) return false;
  int32_t adc_P = ((buf[0]<<16)|(buf[1]<<8)|buf[2])>>4;
  int32_t adc_T = ((buf[3]<<16)|(buf[4]<<8)|buf[5])>>4;

  int32_t var1, var2;
  var1 = ((((adc_T>>3) - ((int32_t)calib.dig_T1<<1))) * ((int32_t)calib.dig_T2)) >> 11;
  var2 = (((((adc_T>>4) - ((int32_t)calib.dig_T1)) * ((adc_T>>4) - ((int32_t)calib.dig_T1))) >> 12) * ((int32_t)calib.dig_T3)) >> 14;
  calib.t_fine = var1 + var2;

  int64_t var1p, var2p, p;
  var1p = ((int64_t)calib.t_fine) - 128000;
  var2p = var1p * var1p * (int64_t)calib.dig_P6;
  var2p = var2p + ((var1p*(int64_t)calib.dig_P5)<<17);
  var2p = var2p + (((int64_t)calib.dig_P4)<<35);
  var1p = ((var1p * var1p * (int64_t)calib.dig_P3)>>8) + ((var1p * (int64_t)calib.dig_P2)<<12);
  var1p = (((((int64_t)1)<<47)+var1p))*((int64_t)calib.dig_P1)>>33;
  if (var1p == 0) return false;
  p = 1048576 - adc_P;
  p = (((p<<31) - var2p) * 3125) / var1p;
  var1p = (((int64_t)calib.dig_P9) * (p>>13) * (p>>13)) >> 25;
  var2p = (((int64_t)calib.dig_P8) * p) >> 19;
  p = ((p + var1p + var2p) >> 8) + (((int64_t)calib.dig_P7)<<4);
  *pressure_hpa = p/25600.0f;
  return true;
}


