/*
 * can_interface.h
 *
 *  Created on: Aug 12, 2025
 *      Author: ASUS
 */
#ifndef CAN_INTERFACE_H
#define CAN_INTERFACE_H

#include "stm32f1xx_hal.h"
#include <stdint.h>
#include <stdbool.h>

typedef struct {
  uint32_t id;
  uint8_t len;
  uint8_t data[8];
} CANMessage;

void CAN_IF_Init(CAN_HandleTypeDef *hcan);
bool CAN_IF_Send(CAN_HandleTypeDef *hcan, const CANMessage *msg);
typedef void (*can_req_cb_t)(const CANMessage *msg);
void CAN_IF_RegisterRequestCallback(can_req_cb_t cb);

#endif
