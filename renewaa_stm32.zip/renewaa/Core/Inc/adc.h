/*
 * adc.h
 *
 *  Created on: Aug 12, 2025
 *      Author: ASUS
 */

#ifndef __ADC_H
#define __ADC_H

#include "stm32f1xx_hal.h"

// Initialize ADC on PA1 (ADC Channel 1)
void ADC_Init(void);

// Read ADC value from PA1
uint16_t ADC_Read(void);

#endif /* __ADC_H */
