/*
 * sensor_manager.h
 *
 *  Created on: Aug 12, 2025
 *      Author: ASUS
 */

#ifndef SENSOR_MANAGER_H
#define SENSOR_MANAGER_H

#include "stm32f1xx_hal.h"
#include <stdint.h>

typedef struct {
  float temperature;
  float humidity;
  float gas_ppm;
  float pressure;

} SensorData;

void SensorMgr_Init(I2C_HandleTypeDef *hi2c, ADC_HandleTypeDef *hadc);
void SensorMgr_Update(void);
SensorData SensorMgr_GetData(void);



#endif /* INC_SENSOR_MANAGER_H_ */
