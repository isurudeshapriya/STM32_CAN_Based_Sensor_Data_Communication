/*
 * bmp280.h
 *
 *  Created on: Aug 12, 2025
 *      Author: ASUS
 */

#ifndef BMP280_H
#define BMP280_H

#include "stm32f1xx_hal.h"
#include <stdbool.h>

bool BMP280_Init(I2C_HandleTypeDef *hi2c);
bool BMP280_ReadPressure(I2C_HandleTypeDef *hi2c, float *pressure_hpa);




#endif /* INC_BMP280_H_ */
